package com.FlightTicketBooking.flight;

public class Flight {
	private String flightId;
	private String flightName;
	private String Source;
	private String Destination;
	private String dispatchingTime;
	private String arrivalTime;
	private int businessClass;
	private int firstClass;
	private String date;
	private int businessClassTicketAmount;
	private int firstClassTicketAmount;
	
	public Flight(String flightId, String flightName, String source, String destination, String dispatchingTime,
			String arrivalTime, int businessClass, int firstClass, int businessClassTicketAmount,
			int firstClassTicketAmount, String date) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.Source = source;
		this.Destination = destination;
		this.dispatchingTime=dispatchingTime;
		this.arrivalTime=arrivalTime;
		this.setBusinessClass(businessClass);
		this.setFirstClass(firstClass);
		this.setBusinessClassTicketAmount(businessClassTicketAmount);
		this.setFirstClassTicketAmount(firstClassTicketAmount);
		this.date = date;
	}

	
	public String getDestination() {
		return Destination;
	}
	public void setDestination(String destination) {
		Destination = destination;
	}
	public String getSource() {
		return Source;
	}
	public void setSource(String source) {
		Source = source;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getFlightId() {
		return flightId;
	}
	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}



	public int getBusinessClass() {
		return businessClass;
	}



	public void setBusinessClass(int businessClass) {
		this.businessClass = businessClass;
	}



	public int getFirstClass() {
		return firstClass;
	}



	public void setFirstClass(int firstClass) {
		this.firstClass = firstClass;
	}



	public int getBusinessClassTicketAmount() {
		return businessClassTicketAmount;
	}



	public void setBusinessClassTicketAmount(int businessClassTicketAmount) {
		this.businessClassTicketAmount = businessClassTicketAmount;
	}

	public int getFirstClassTicketAmount() {
		return firstClassTicketAmount;
	}
	public void setFirstClassTicketAmount(int firstClassTicketAmount) {
		this.firstClassTicketAmount = firstClassTicketAmount;
	}


	public String getDispatchingTime() {
		return dispatchingTime;
	}


	public void setDispatchingTime(String dispatchingTime) {
		this.dispatchingTime = dispatchingTime;
	}


	public String getArrivalTime() {
		return arrivalTime;
	}


	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	
}
