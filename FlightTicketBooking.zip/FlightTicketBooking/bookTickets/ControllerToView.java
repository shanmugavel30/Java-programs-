package com.FlightTicketBooking.bookTickets;

public interface ControllerToView {

}
