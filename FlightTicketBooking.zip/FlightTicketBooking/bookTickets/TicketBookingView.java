package com.FlightTicketBooking.bookTickets;
import java.util.*;

import com.FlightTicketBooking.flight.Flight;
import com.FlightTicketBooking.login.LoginView;
public class TicketBookingView {
	
	TicketBookingController bookcontroller;
	private Scanner scanner = new Scanner(System.in);
	
	public TicketBookingView() {
		bookcontroller=new TicketBookingController(this);
	}
	
	public void bookFlights(List<Flight> flightsDetails,String passengerName) {
		System.out.println("___---Welcome to My Flight Booking Website---___");
		System.out.println("Enter Flight ID: ");
		String fId=scanner.next();
		System.out.println("Enter No of business seats: ");
		int bseats=scanner.nextInt();
		System.out.println("Enter No of firstclass seats: ");
		int fseats=scanner.nextInt();
		checkingDetails(fId, bseats, fseats, flightsDetails,passengerName);
		
	}

	private void checkingDetails(String fId, int bseats, int fseats, List<Flight> flightsDetails,
			String passengerName) {
		for (int i = 0; i < flightsDetails.size(); ++i) {

			if (flightsDetails.get(i).getFlightId().equals(fId)) {

				boolean flightAvailable = true;
				if (flightsDetails.get(i).getBusinessClass() < bseats) {
					bseats(i, flightsDetails);
					flightAvailable = false;
				}
				if (flightsDetails.get(i).getFirstClass() < fseats) {
					fseats(i, flightsDetails);
					flightAvailable = false;
				}
				
				if (flightAvailable == true) {
					bookcontroller.addDetails(passengerName,i,flightsDetails,bseats,fseats);
				}
			} else {
				
				System.out.println("Flight Id Not Found");
			}
		}
		
	}

	private void fseats(int i, List<Flight> flightsDetails) {
		System.out.println("business Class seats only " + flightsDetails.get(i).getBusinessClass() + " Available");
	}

	private void bseats(int i, List<Flight> flightsDetails) {
		System.out.println("First Class seats only " + flightsDetails.get(i).getFirstClass() + " Available");
	}
	
	public void addSuccess() {
		System.out.println("Added Successfully");
		new LoginView().loginWeb();
	}
}
