package com.FlightTicketBooking.bookTickets;

import java.util.List;

import com.FlightTicketBooking.bookingdetails.BookingDetailsRepository;
import com.FlightTicketBooking.flight.Flight;
import com.FlightTicketBooking.flightdetails.FlightDetailsRepository;
import com.FlightTicketBooking.passengerdetails.PassengerDetailsRepository;

public class TicketBookingModel {
	private static int bookingId = 0;
	private static int passengerId = 0;

	TicketBookingController bookcontroller;
	
	public TicketBookingModel(TicketBookingController bookcontroller) {
		this.bookcontroller=bookcontroller;
	}

	public void addDetails(String passengerName, int i, List<Flight> flightsDetails, int bseats, int fseats) {
		int amount = bseats * flightsDetails.get(i).getBusinessClassTicketAmount()
				+ fseats * flightsDetails.get(i).getFirstClassTicketAmount();
		
		BookingDetailsRepository.getInstance().addBookingDetails(++bookingId, ++passengerId,
				flightsDetails.get(i).getFlightId(), flightsDetails.get(i).getFlightName(),
				flightsDetails.get(i).getSource(), flightsDetails.get(i).getDestination(),
				flightsDetails.get(i).getDispatchingTime(), flightsDetails.get(i).getArrivalTime(), bseats,
				fseats, amount);
		
		PassengerDetailsRepository.getInstance().addPassengerDetails(passengerId, passengerName,
				flightsDetails.get(i).getFlightId(), flightsDetails.get(i).getFlightName(),
				flightsDetails.get(i).getSource(), flightsDetails.get(i).getDestination(),
				flightsDetails.get(i).getDispatchingTime(), flightsDetails.get(i).getArrivalTime(), bseats,
				fseats, amount, flightsDetails.get(i).getDate());
		
		FlightDetailsRepository.getInstance().setBusinessClassSeats(flightsDetails.get(i).getFlightId(),
				flightsDetails.get(i).getBusinessClass(), bseats,false);
		
		FlightDetailsRepository.getInstance().setBusinessClassSeats(flightsDetails.get(i).getFlightId(),
				flightsDetails.get(i).getFirstClass(), fseats,false);
		
		bookcontroller.addSuccess();
	}
}
