package com.FlightTicketBooking.bookTickets;

public class FlightBooking {
	private int bookingId;
	private int  passengerId;
	private String PassengerName;
	private int flightId;
	private String source;
	private String destination;
	private String dispatchingTime;
	private String arrivalTime;
	private int amount;
	private int businessClassSeats;
	private int firstClassSeats;
	
	public FlightBooking(int bookingId,int passengerId,String PassengerName,int flightId,String source,String destination,String dispatchingTime,String arrivalTime,int amount,int businessClassSeats,int firstClassSeats) {
		super();
		this.setBookingId(bookingId);
		this.setPassengerId(passengerId);
		this.setPassengerName(PassengerName);
		this.setFlightId(flightId);
		this.setSource(source);
		this.setDestination(destination);
		this.setDispatchingTime(dispatchingTime);
		this.setArrivalTime(arrivalTime);
		this.setAmount(amount);
		this.setBusinessClassSeats(businessClassSeats);
		this.setFirstClassSeats(firstClassSeats);
		
	}

	

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public String getPassengerName() {
		return PassengerName;
	}

	public void setPassengerName(String passengerName) {
		PassengerName = passengerName;
	}

	public int getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public String getDispatchingTime() {
		return dispatchingTime;
	}

	public void setDispatchingTime(String dispatchingTime) {
		this.dispatchingTime = dispatchingTime;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public int getBusinessClassSeats() {
		return businessClassSeats;
	}

	public void setBusinessClassSeats(int businessClassSeats) {
		this.businessClassSeats = businessClassSeats;
	}

	public int getFirstClassSeats() {
		return firstClassSeats;
	}

	public void setFirstClassSeats(int firstClassSeats) {
		this.firstClassSeats = firstClassSeats;
	}
}
