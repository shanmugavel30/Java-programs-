package com.FlightTicketBooking.bookTickets;

public interface ControllerToModel {

}
