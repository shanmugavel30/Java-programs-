package com.FlightTicketBooking.bookTickets;

import java.util.List;

import com.FlightTicketBooking.flight.Flight;

public class TicketBookingController {
	
	private TicketBookingView bookview;
	private TicketBookingModel bookmodel;
	
	public TicketBookingController(TicketBookingView checkview) {
		this.bookview=checkview;
		this.bookmodel=new TicketBookingModel(this);
	}
	public void addDetails(String passengerName, int i, List<Flight> flightsDetails, int bseats, int fseats) {
		bookmodel.addDetails(passengerName,i,flightsDetails,bseats,fseats);
	}
	public void addSuccess() {		
		bookview.addSuccess();
	}
		
	

}
