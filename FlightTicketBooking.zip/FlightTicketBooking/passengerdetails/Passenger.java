package com.FlightTicketBooking.passengerdetails;

public class Passenger {
	
	private int passengerId;
	private String passengerName;
	private String flightId;
	private String flightName;
	private String source;
	private String destination;
	private String dispatchingTime;
	private String arrivalTime;
	private int businessClass;
	private int firstClass;
	private int amount;
	private String date;

	public Passenger(int passengerId, String passengerName, String source, String destination, String flightId,
			String flightName,String arrivalTime,String dispatchingTime, int businessClass, int firstClass, int amount, String date) {
		super();
		this.passengerId = passengerId;
		this.passengerName = passengerName;
		this.source = source;
		this.destination = destination;
		this.flightId = flightId;
		this.flightName = flightName;
		this.businessClass = businessClass;
		this.firstClass = firstClass;
		this.amount = amount;
		this.date = date;
		this.dispatchingTime = dispatchingTime;
		this.arrivalTime = arrivalTime;
	}

	public int getBusinessClass() {
		return businessClass;
	}

	public void setBusinessClass(int businessClass) {
		this.businessClass = businessClass;
	}

	public int getFirstClass() {
		return firstClass;
	}

	public void setFirstClass(int firstClass) {
		this.firstClass = firstClass;
	}

	public int getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getFlightId() {
		return flightId;
	}

	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	public String getDispatchingTime() {
		return dispatchingTime;
	}

	public void setDispatchingTime(String dispatchingTime) {
		this.dispatchingTime = dispatchingTime;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

}
