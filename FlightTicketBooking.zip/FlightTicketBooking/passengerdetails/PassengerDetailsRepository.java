package com.FlightTicketBooking.passengerdetails;
import java.util.*;
public class PassengerDetailsRepository {
	private Map<Integer, Passenger> passengerDetails = new HashMap<>();
	private static PassengerDetailsRepository passengerDetailsRepository;

	private PassengerDetailsRepository() {
	}

	public static PassengerDetailsRepository getInstance() {

		if (passengerDetailsRepository == null) {

			passengerDetailsRepository = new PassengerDetailsRepository();
		}

		return passengerDetailsRepository;
	}

	public void addPassengerDetails(int passengerId, String passengerName, String flightId, String flightName,
			String source, String destination,String dispatchingTime,String arrivalTime, int businessClass, int firstClass, int amount,
			String date) {

		Passenger passengerDetail = new Passenger(passengerId, passengerName, source, destination, flightId, flightName,dispatchingTime,arrivalTime,
				businessClass, firstClass, amount, date);
		passengerDetails.put(passengerId, passengerDetail);
	}

	public Passenger removePassengerDetails(int passengerId) {

		if (passengerDetails.containsKey(passengerId)) {

			Passenger detail =  passengerDetails.get(passengerId);
			passengerDetails.remove(passengerId);
			return detail;
		} else {

			return null;
		}
	}
}
