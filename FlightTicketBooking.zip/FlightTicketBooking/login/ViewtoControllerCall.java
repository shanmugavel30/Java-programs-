package com.FlightTicketBooking.login;

public interface ViewtoControllerCall {
	void checkAdmin(String adminName, String pass);
	void checkPass(String pname);
}
