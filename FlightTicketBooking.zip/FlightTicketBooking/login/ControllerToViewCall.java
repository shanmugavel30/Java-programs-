package com.FlightTicketBooking.login;

public interface ControllerToViewCall {
	void passangerSuccess(String Name);
	void adminSuccess(String Name);
}
