package com.FlightTicketBooking.login;
import java.util.*;

import com.FlightTicketBooking.passanger.PassengerView;
public class LoginView implements ControllerToViewCall{

	private ViewtoControllerCall logincontroller;
	private Scanner scanner=new Scanner(System.in);

	public LoginView() {
		logincontroller = new LoginController(this);
	}
	public static void main(String[] args) {
		LoginView obj=new LoginView();
		obj.loginWeb();
	}

	public void loginWeb() {
		System.out.println("..-->Welcome to easy flight ticket booking website..<--");
		System.out.println("---____There are Two Login____---");
		System.out.println("1.Passenger Login \n2.Admin Login\n3.Exit");
		System.out.println();
		System.out.println("Please Enter your choice:");
		int choice=scanner.nextInt();
		if(choice==1) {
			System.out.println("Enter the Passanger Name:");
			String Pname=scanner.next();
			logincontroller.checkPass(Pname);
		}
		else if(choice==2) {
			System.out.println("Enter the Admin Name:");
			String AdminName=scanner.next();
			System.out.println("Enter the password:");
			String pass=scanner.next();
			logincontroller.checkAdmin(AdminName,pass);
		}
		else {
			System.out.println("!...Exitted...!");
		}
	}
	
	public void passangerSuccess(String Name) {
		System.out.println("Passenger Loggedin successfully with "+Name+" name.");
		PassengerView linktopass  =new PassengerView();
		linktopass.homePage(Name);
	}
	public void adminSuccess(String Name) {
		System.out.println("Admin Loggedin successfully with "+Name+" name.");
		
	}

}
