package com.FlightTicketBooking.login;

public class LoginModel implements ControllerToModelCall {
	
	private ModelToController logincontroller;
	public LoginModel(LoginController logincontroller) {
		this.logincontroller=logincontroller;
	}
	public void checkIsAdmin(String adminName, String pass) {
		if(adminName.equals("selvam")) {
			if(pass.equals("30OCT")) {
				logincontroller.adminLogin(adminName);
			}
		}
		else {
			System.out.println("Enter correct AdminName.");
		}
	}
	
	public void checkIsPassenger(String Name) {
		if(Name.isEmpty()) {
			System.out.println("Please Enter the valid Passanger Name");
		}
		logincontroller.passengerLogin(Name);
	}
	
}
