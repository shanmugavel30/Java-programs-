package com.FlightTicketBooking.login;

public class LoginController implements ModelToController,ViewtoControllerCall{
	
	private ControllerToModelCall loginmodel;
	private ControllerToViewCall loginview;
	
	public LoginController(LoginView loginview) {
		this.loginview=loginview;
		this.loginmodel=new LoginModel(this);
	}

	public void checkAdmin(String adminName, String pass) {
		loginmodel.checkIsAdmin(adminName,pass);		
	}
	public void checkPass(String pname) {
		loginmodel.checkIsPassenger(pname);
	}

	public void adminLogin(String adminName) {
		loginview.adminSuccess(adminName);
	}

	public void passengerLogin(String name) {
		loginview.passangerSuccess(name);
	}	
}
