package com.FlightTicketBooking.login;

public interface ControllerToModelCall {
	void checkIsAdmin(String adminName, String pass);
	void checkIsPassenger(String Name);
}
