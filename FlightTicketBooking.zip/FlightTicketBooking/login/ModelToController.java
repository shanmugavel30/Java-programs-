package com.FlightTicketBooking.login;

public interface ModelToController {
	void adminLogin(String adminName);
	void passengerLogin(String Name);
}
