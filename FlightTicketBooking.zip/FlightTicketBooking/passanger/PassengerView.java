package com.FlightTicketBooking.passanger;
import java.util.*;

import com.FlightTicketBooking.CancelTickets.CancelView;
import com.FlightTicketBooking.bookTickets.TicketBookingView;
import com.FlightTicketBooking.flight.Flight;
public class PassengerView {
	private PassengerController passcontroller;
	private Scanner scanner=new Scanner(System.in);
	public PassengerView() {
		passcontroller = new PassengerController(this);
	}
	
	public void homePage(String passengerName) {

		System.out.println("1) Ticket Booking\n2) Ticket Cancelation\n3) Exit");
		System.out.print("Please!!! Enter the Option : ");
		int option = scanner.nextInt();
		if (option == 1) {

			detailsOfFlight(passengerName);
		} else if (option == 2) {
			
			CancelView obj = new CancelView();
			obj.ticketCancel();
		}  else {

			System.out.println("Exitted!!!");
		}
	}
	
	public void detailsOfFlight(String pName) {
		System.out.println("Enter the source:");
		String source=scanner.next();
		System.out.println("Enter the Destination:");
		String destination=scanner.next();
		System.out.println("Enter the Date:");
		String date=scanner.next();
		
		passcontroller.checkFlight(source,destination,date,pName);
				
	}
	public void flightsNotFound() {

		System.out.println("No Flights Available!!!");
	}
	
	public void flightsFound(List<Flight> flightsList,String passengerName) {

		System.out.println(
				"\nFlight Id\tFlight Name\tSDispatching time\tArrival time\tbclass\tfclass\tbamount\tfamount\tdate");
		for (int i = 0; i < flightsList.size(); ++i) {

			System.out.println("\n" + flightsList.get(i).getFlightId() + "\t\t" + flightsList.get(i).getFlightName()
					+ "\t" + flightsList.get(i).getDispatchingTime() + "\t\t\t" + flightsList.get(i).getArrivalTime()
					+ "\t\t" + flightsList.get(i).getBusinessClass() + "\t" + flightsList.get(i).getFirstClass() + "\t"
					 + flightsList.get(i).getBusinessClassTicketAmount()+ "\t" + flightsList.get(i).getFirstClassTicketAmount()+ "\t" + flightsList.get(i).getDate());
		}
		TicketBookingView linktoBook = new TicketBookingView();
		linktoBook.bookFlights(flightsList,passengerName);
}
}
