package com.FlightTicketBooking.passanger;

public interface ControllerToModel {

}
