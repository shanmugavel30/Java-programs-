package com.FlightTicketBooking.passanger;

import java.util.List;

import com.FlightTicketBooking.flight.Flight;
import com.FlightTicketBooking.flightdetails.FlightDetailsRepository;

public class PassengerModel {
	
	private PassengerController passcontroller;
	
	public PassengerModel(PassengerController passcontroller) {
		this.passcontroller=passcontroller;
	}

	public void checkFlightAvail(String source, String destination, String date,String pName) {
		List<Flight> flightsList = FlightDetailsRepository.getInstance().getFlights(source, destination, date);
		if (flightsList.isEmpty()) {

			passcontroller.flightsNotFound();
		} else {

			passcontroller.flightsFound(flightsList,pName);
		}
		
	}

}
