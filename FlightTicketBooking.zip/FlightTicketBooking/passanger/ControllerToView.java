package com.FlightTicketBooking.passanger;

public interface ControllerToView {

}
