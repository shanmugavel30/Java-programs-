package com.FlightTicketBooking.passanger;

public interface ViewToController {

}
