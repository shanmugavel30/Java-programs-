package com.FlightTicketBooking.passanger;

public interface ModelToController {

}
