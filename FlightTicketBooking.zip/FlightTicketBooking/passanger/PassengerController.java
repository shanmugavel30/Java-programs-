package com.FlightTicketBooking.passanger;
import java.util.*;

import com.FlightTicketBooking.flight.Flight;

public class PassengerController {
	private PassengerModel passmod;
	private PassengerView passview;
	
	public PassengerController(PassengerView passview) {
		this.passview=passview;
		this.passmod=new PassengerModel(this);
	}

	public void checkFlight(String source, String destination, String date,String pName) {
		passmod.checkFlightAvail(source,destination,date,pName);
	}
	
	public void flightsNotFound() {

		passview.flightsNotFound();
	}
	public void flightsFound(List<Flight> flightsList, String passengerName) {

		passview.flightsFound(flightsList, passengerName);
	}
}
