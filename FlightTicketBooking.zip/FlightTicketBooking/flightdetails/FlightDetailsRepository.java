package com.FlightTicketBooking.flightdetails;
import java.util.*;

import com.FlightTicketBooking.flight.Flight;
public class FlightDetailsRepository {
	private Map<String, Flight> flightDetails = new HashMap<>();
	private static FlightDetailsRepository flightDetailsRepository;
	private Flight flight;

	private FlightDetailsRepository() {

		flight = new Flight("0001", "AirAsia India", "tenkasi", "chennai","6PM","7PM", 15, 15, 1000, 500, "23/02/23");
		flightDetails.put("0001", flight);

		flight = new Flight("0002", "Air India", "chennai", "madurai", "08.30PM", "09.15AM", 15, 15, 900, 500,"18/02/23");
		flightDetails.put("0002", flight);

		flight = new Flight("0003", "Air India Express", "kaniyakumari", "kashmir", "04.00AM", "09.00AM", 15, 15, 6000, 4000,"20/02/23");
		flightDetails.put("0003", flight);

		flight = new Flight("0004", "Go First", "chennai", "pune", "06.00AM", "07.30AM", 15, 15,1800, 900,"21/02/23");
		flightDetails.put("0004", flight);

		flight = new Flight("0005", "IndiGo", "madurai", "kalkata", "10.15AM", "11.30AM", 15, 15, 900, 500,"23/02/23");
		flightDetails.put("0005", flight);
	}

	public static FlightDetailsRepository getInstance() {

		if (flightDetailsRepository == null) {

			flightDetailsRepository = new FlightDetailsRepository();
		}

		return flightDetailsRepository;
	}

	public boolean addFlightDetailss(String flightId, String flightName, String source, String destination,
			String dispatchingTime, String arrivalTime, int businessClass, int firstClass, int economicClass,
			int businessClassTicketAmount, int firstClassTicketAmount, int economicClassTicketAmount, String date) {

		if (flightDetails.containsKey(flightId)) {

			return false;
		} else {
			Flight flight = new Flight(flightId, flightName, source, destination, dispatchingTime, arrivalTime,
					businessClass, firstClass, businessClassTicketAmount, firstClassTicketAmount, date);
			flightDetails.put(flightId, flight);
			return true;
		}
	}

	public boolean modifyFlightDetails(String flightId, String flightName, String source, String destination,
			String dispatchingTime, String arrivalTime, int businessClass, int firstClass,
			int businessClassTicketAmount, int firstClassTicketAmount, String date) {
		
		if (flightDetails.containsKey(flightId)) {

			Flight flight = new Flight(flightId, flightName, source, destination, dispatchingTime, arrivalTime,
					businessClass, firstClass, businessClassTicketAmount, firstClassTicketAmount, date);
			flightDetails.put(flightId, flight);
			return true;
		} else {
			return false;
		}
	}

	public boolean deleteFlightDetails(String flightId) {

		if (flightDetails.containsKey(flightId)) {

			flightDetails.remove(flightId);
			return true;
		} else {

			return false;
		}
	}

	public List<Flight> getFlights(String source, String destination, String date) {

		List<Flight> flightsList = new LinkedList<>();
		for (Map.Entry<String, Flight> entry : flightDetails.entrySet()) {

			if (entry.getValue().getSource().equals(source) && entry.getValue().getDestination().equals(destination)
					&& entry.getValue().getDate().equals(date)) {

				flightsList.add(entry.getValue());
			}
		}
		return flightsList;
	}

	public void setBusinessClassSeats(String flightId, int totalSeats, int seats, boolean add) {

		if (add = true) {
			
			flightDetails.get(flightId).setBusinessClass(flightDetails.get(flightId).getBusinessClass() + seats);
		} else {

			flightDetails.get(flightId).setBusinessClass(totalSeats - seats);
		}

	}

	public void setFirstClassSeats(String flightId, int totalSeats, int seats, boolean add) {

		if (add == true) {

			flightDetails.get(flightId).setFirstClass(flightDetails.get(flightId).getFirstClass() + seats);
		} else {

			flightDetails.get(flightId).setFirstClass(totalSeats - seats);
		}

	}

	
}
