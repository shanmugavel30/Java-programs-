package com.FlightTicketBooking.flightreservation;

public class FlightBooking {

	private int bookingId;
	private int passengerId;
	private String flightName;
	private String flightId;
	private String source;
	private String destination;
	private String dispatchingTime;
	private String arrivalTime;
	private int amount;
	private int businessClassSeats;
	private int firstClassSeats;

	public FlightBooking(int bookingId, int passengerId, String flightName, String flightId, String source,
			String destination, String dispatchingTime, String arrivalTime, int amount, int businessClassSeats,int firstClassSeats) {
		super();
		this.bookingId = bookingId;
		this.passengerId = passengerId;
		this.setFlightName(flightName);
		this.flightId = flightId;
		this.source = source;
		this.destination = destination;
		this.setDispatchingTime(dispatchingTime);
		this.setArrivalTime(arrivalTime);
		this.setAmount(amount);
		this.businessClassSeats = businessClassSeats;
		this.firstClassSeats = firstClassSeats;
	
	}
	public int getBusinessClassSeats() {
		return businessClassSeats;
	}

	public void setBusinessClassSeats(int businessClassSeats) {
		this.businessClassSeats = businessClassSeats;
	}

	public int getFirstClassSeats() {
		return firstClassSeats;
	}

	public void setFirstClassSeats(int firstClassSeats) {
		this.firstClassSeats = firstClassSeats;
	}

	
	public int getBookingId() {
		return bookingId;
	}
	
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}

	public String getFlightId() {
		return flightId;
	}

	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public String getDispatchingTime() {
		return dispatchingTime;
	}
	public void setDispatchingTime(String dispatchingTime) {
		this.dispatchingTime = dispatchingTime;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	
}
