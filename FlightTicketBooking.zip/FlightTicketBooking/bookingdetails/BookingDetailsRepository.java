package com.FlightTicketBooking.bookingdetails;
import java.util.*;

import com.FlightTicketBooking.flightreservation.FlightBooking;

public class BookingDetailsRepository {
	private Map<Integer, FlightBooking> bookingDetails = new HashMap<>();
	private static BookingDetailsRepository bookingDetailsRepository;

	private BookingDetailsRepository() {

	}

	public static BookingDetailsRepository getInstance() {

		if (bookingDetailsRepository == null) {

			bookingDetailsRepository = new BookingDetailsRepository();
		}
		return bookingDetailsRepository;
	}

	public void addBookingDetails(int bookingId, int passengerId, String flightId, String flightName, String source,
			String destination, String dispatchingTime, String arrivalTime, int noOfbcSeats, int noOffcSeats, int amount) {

		FlightBooking booking = new FlightBooking(bookingId, passengerId, flightId, flightName, source, destination,
				dispatchingTime, arrivalTime, noOfbcSeats, noOffcSeats, amount);
		bookingDetails.put(bookingId, booking);
	}
	public void removeBookingDetails(int bookingId) {
		
		bookingDetails.remove(bookingId);
	}
	public FlightBooking checkBookingId(int bookingId) {
		
//		detail = new LinkedList<>();
		if(bookingDetails.containsKey(bookingId)) {
			
			FlightBooking detail = bookingDetails.get(bookingId);
			bookingDetails.remove(bookingId);
			return detail;
		}
		return null;
	}

}
