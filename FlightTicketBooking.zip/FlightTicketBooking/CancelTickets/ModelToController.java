package com.FlightTicketBooking.CancelTickets;

public interface ModelToController {

	void removeSuccess();

	void removeFailed();

}
