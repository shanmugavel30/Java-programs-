package com.FlightTicketBooking.CancelTickets;

public interface ControllerToView {

	void removeSuccess();

	void removeFailed();

}
