package com.FlightTicketBooking.CancelTickets;


public class CancelController implements ModelToController,ViewToController {
	
	private ControllerToModel cancelmodel;
	private ControllerToView cancelview;
	
	public CancelController(CancelView cancelview) {
		this.cancelview=cancelview;
		this.cancelmodel=new CancelModel(this);
	}
	
	public void checkBookingIdAndpassengerId(int bookingId, int passengerId) {
		
		cancelmodel.checkBookingIdAndpassengerId(bookingId,passengerId);
	}
	public void removeSuccess() {
		
		cancelview.removeSuccess();
	}

	@Override
	public void removeFailed() {
		
		cancelview.removeFailed();
	}

	
}
