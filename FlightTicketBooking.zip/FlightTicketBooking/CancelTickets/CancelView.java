package com.FlightTicketBooking.CancelTickets;

import java.util.Scanner;

import com.FlightTicketBooking.login.LoginView;

public class CancelView implements ControllerToView{
	private ViewToController cancelcontroller;
	private Scanner scanner=new Scanner(System.in);

	public CancelView() {
		cancelcontroller = new CancelController(this);
	}
	public void ticketCancel() {

		System.out.println("----->>Ticket Cancelation<<-------");
		System.out.print("Enter the passenger id : ");
		int passengerId = scanner.nextInt();
		System.out.print("Enter the booking id : ");
		int bookingId = scanner.nextInt();
		cancelcontroller.checkBookingIdAndpassengerId(bookingId, passengerId);
	}
	
	public void removeFailed() {
		System.out.println("Passenger Id Or Booking Id Not Exist");
	}

	@Override
	public void removeSuccess() {

		System.out.println("Yout Booking Cancelled Successfully");
		new LoginView().loginWeb();
	}
	
}
