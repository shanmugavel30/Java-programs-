package com.FlightTicketBooking.CancelTickets;

public interface ViewToController {

	//void checkId(int bookingId, int passId);

	void checkBookingIdAndpassengerId(int bookingId, int passengerId);

}
