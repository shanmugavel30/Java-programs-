package com.FlightTicketBooking.CancelTickets;

import com.FlightTicketBooking.bookTickets.FlightBooking;
import com.FlightTicketBooking.bookingdetails.BookingDetailsRepository;
import com.FlightTicketBooking.flightdetails.FlightDetailsRepository;
import com.FlightTicketBooking.passengerdetails.Passenger;
import com.FlightTicketBooking.passengerdetails.PassengerDetailsRepository;

public class CancelModel implements ControllerToModel{
	private ModelToController cancelcontroller;
	
	public CancelModel(CancelController cancelcontroller) {
		this.cancelcontroller=cancelcontroller;
	}

	
	public void checkBookingIdAndpassengerId(int bookingId, int passengerId) {
		
		
		com.FlightTicketBooking.flightreservation.FlightBooking details= BookingDetailsRepository.getInstance().checkBookingId(bookingId);
		Passenger passDetails = PassengerDetailsRepository.getInstance().removePassengerDetails(passengerId);
	
		if(passDetails != null && details != null) {
			
			FlightDetailsRepository.getInstance().setBusinessClassSeats(passDetails.getFlightId(),details.getBusinessClassSeats(),0,true);
			FlightDetailsRepository.getInstance().setFirstClassSeats(passDetails.getFlightId(),details.getFirstClassSeats(),0,true);
			cancelcontroller.removeSuccess();
		}
		else {		
			cancelcontroller.removeFailed();
		}
	}

}
