package com.FlightTicketBooking.CancelTickets;

public interface ControllerToModel {

	

	void checkBookingIdAndpassengerId(int bookingId, int passengerId);

	//void checkBookingIdAndpassengerId(int bookingId, int passengerId);

}
